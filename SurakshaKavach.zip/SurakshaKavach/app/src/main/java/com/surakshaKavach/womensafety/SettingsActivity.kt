package com.surakshaKavach.womensafety

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.surakshaKavach.womensafety.databinding.ActivitySettingsBinding

/**
 * SettingsActivity - Configure app settings
 * - Emergency phone number
 * - Alert message customization
 * - Alarm settings
 */
class SettingsActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivitySettingsBinding
    private lateinit var prefs: SharedPreferences
    
    companion object {
        const val PREFS_NAME = "SurakshaKavachPrefs"
        const val KEY_EMERGENCY_NUMBER = "emergency_number"
        const val KEY_ALERT_MESSAGE = "alert_message"
        const val KEY_ENABLE_ALARM = "enable_alarm"
        const val KEY_AUTO_CALL = "auto_call"
        
        const val DEFAULT_EMERGENCY_NUMBER = "112" // Indian emergency number
        const val DEFAULT_ALERT_MESSAGE = "🚨 EMERGENCY! I need help. My current location: "
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Settings"
        
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        
        loadSettings()
        setupListeners()
    }
    
    private fun loadSettings() {
        binding.etEmergencyNumber.setText(
            prefs.getString(KEY_EMERGENCY_NUMBER, DEFAULT_EMERGENCY_NUMBER)
        )
        
        binding.etAlertMessage.setText(
            prefs.getString(KEY_ALERT_MESSAGE, DEFAULT_ALERT_MESSAGE)
        )
        
        binding.switchAlarm.isChecked = prefs.getBoolean(KEY_ENABLE_ALARM, true)
        binding.switchAutoCall.isChecked = prefs.getBoolean(KEY_AUTO_CALL, true)
    }
    
    private fun setupListeners() {
        binding.btnSaveSettings.setOnClickListener {
            saveSettings()
        }
        
        binding.btnResetSettings.setOnClickListener {
            resetToDefaults()
        }
    }
    
    private fun saveSettings() {
        val emergencyNumber = binding.etEmergencyNumber.text.toString().trim()
        val alertMessage = binding.etAlertMessage.text.toString().trim()
        
        if (emergencyNumber.isEmpty()) {
            Toast.makeText(this, "Please enter emergency number", Toast.LENGTH_SHORT).show()
            return
        }
        
        if (alertMessage.isEmpty()) {
            Toast.makeText(this, "Please enter alert message", Toast.LENGTH_SHORT).show()
            return
        }
        
        prefs.edit().apply {
            putString(KEY_EMERGENCY_NUMBER, emergencyNumber)
            putString(KEY_ALERT_MESSAGE, alertMessage)
            putBoolean(KEY_ENABLE_ALARM, binding.switchAlarm.isChecked)
            putBoolean(KEY_AUTO_CALL, binding.switchAutoCall.isChecked)
            apply()
        }
        
        Toast.makeText(this, "Settings saved successfully", Toast.LENGTH_SHORT).show()
        finish()
    }
    
    private fun resetToDefaults() {
        binding.etEmergencyNumber.setText(DEFAULT_EMERGENCY_NUMBER)
        binding.etAlertMessage.setText(DEFAULT_ALERT_MESSAGE)
        binding.switchAlarm.isChecked = true
        binding.switchAutoCall.isChecked = true
        
        Toast.makeText(this, "Settings reset to defaults", Toast.LENGTH_SHORT).show()
    }
    
    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
