/*
 * Copyright (c) 2026 Megha Dey. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.surakshaKavach.womensafety.database

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.surakshaKavach.womensafety.models.EmergencyContact

/**
 * SQLite database helper for managing emergency contact persistence.
 * 
 * Provides CRUD (Create, Read, Update, Delete) operations for emergency contacts
 * stored in local SQLite database. All data is encrypted at rest by the Android
 * system when device encryption is enabled.
 * 
 * Database Schema:
 * - Table: emergency_contacts
 * - Columns: id (PRIMARY KEY), name, phone_number, relationship, created_at
 * 
 * @param context Application context for database access
 * @author Megha Dey
 * @version 1.0
 * @since 2026
 */
class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
    
    companion object {
        private const val DATABASE_NAME = "SurakshaKavach.db"
        private const val DATABASE_VERSION = 1
        
        private const val TABLE_CONTACTS = "emergency_contacts"
        
        private const val COL_ID = "id"
        private const val COL_NAME = "name"
        private const val COL_PHONE = "phone_number"
        private const val COL_RELATIONSHIP = "relationship"
        private const val COL_CREATED_AT = "created_at"
    }
    
    /**
     * Creates the database schema when the database is first created.
     * 
     * @param db The database instance
     */
    override fun onCreate(db: SQLiteDatabase?) {
        val createTableQuery = """
            CREATE TABLE $TABLE_CONTACTS (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_NAME TEXT NOT NULL,
                $COL_PHONE TEXT NOT NULL,
                $COL_RELATIONSHIP TEXT,
                $COL_CREATED_AT INTEGER NOT NULL
            )
        """.trimIndent()
        
        db?.execSQL(createTableQuery)
    }
    
    /**
     * Handles database schema upgrades between versions.
     * Currently drops and recreates the table. In production, implement proper migrations.
     * 
     * @param db The database instance
     * @param oldVersion Previous database version
     * @param newVersion New database version
     */
    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_CONTACTS")
        onCreate(db)
    }
    
    /**
     * Inserts a new emergency contact into the database.
     * 
     * @param contact The emergency contact to add
     * @return The row ID of the newly inserted row, or -1 if an error occurred
     */
    fun addContact(contact: EmergencyContact): Long {
        val db = writableDatabase
        val values = buildContactContentValues(contact)
        values.put(COL_CREATED_AT, System.currentTimeMillis())
        
        return db.insert(TABLE_CONTACTS, null, values)
    }
    
    /**
     * Builds ContentValues from an EmergencyContact object.
     */
    private fun buildContactContentValues(contact: EmergencyContact): ContentValues {
        return ContentValues().apply {
            put(COL_NAME, contact.name)
            put(COL_PHONE, contact.phoneNumber)
            put(COL_RELATIONSHIP, contact.relationship)
        }
    }
    
    /**
     * Retrieves all emergency contacts from the database.
     * Contacts are ordered by creation date (newest first).
     * 
     * @return List of all emergency contacts
     */
    fun getAllContacts(): List<EmergencyContact> {
        val contacts = mutableListOf<EmergencyContact>()
        val db = readableDatabase
        
        db.query(
            TABLE_CONTACTS,
            null,
            null,
            null,
            null,
            null,
            "$COL_CREATED_AT DESC"
        ).use { cursor ->
            if (cursor.moveToFirst()) {
                do {
                    contacts.add(extractContactFromCursor(cursor))
                } while (cursor.moveToNext())
            }
        }
        
        return contacts
    }
    
    /**
     * Extracts an EmergencyContact object from cursor at current position.
     */
    private fun extractContactFromCursor(cursor: android.database.Cursor): EmergencyContact {
        return EmergencyContact(
            id = cursor.getLong(cursor.getColumnIndexOrThrow(COL_ID)),
            name = cursor.getString(cursor.getColumnIndexOrThrow(COL_NAME)),
            phoneNumber = cursor.getString(cursor.getColumnIndexOrThrow(COL_PHONE)),
            relationship = cursor.getString(cursor.getColumnIndexOrThrow(COL_RELATIONSHIP))
        )
    }
    
    /**
     * Updates an existing emergency contact in the database.
     * 
     * @param contact The contact with updated information
     * @return true if the contact was successfully updated, false otherwise
     */
    fun updateContact(contact: EmergencyContact): Boolean {
        val db = writableDatabase
        val values = buildContactContentValues(contact)
        
        val rowsAffected = db.update(
            TABLE_CONTACTS,
            values,
            "$COL_ID = ?",
            arrayOf(contact.id.toString())
        )
        
        return rowsAffected > 0
    }
    
    /**
     * Deletes an emergency contact from the database.
     * 
     * @param contactId The ID of the contact to delete
     * @return true if the contact was successfully deleted, false otherwise
     */
    fun deleteContact(contactId: Long): Boolean {
        val db = writableDatabase
        val rowsDeleted = db.delete(
            TABLE_CONTACTS,
            "$COL_ID = ?",
            arrayOf(contactId.toString())
        )
        
        return rowsDeleted > 0
    }
    
    /**
     * Retrieves a single emergency contact by ID.
     * 
     * @param contactId The ID of the contact to retrieve
     * @return The emergency contact if found, null otherwise
     */
    fun getContactById(contactId: Long): EmergencyContact? {
        val db = readableDatabase
        
        db.query(
            TABLE_CONTACTS,
            null,
            "$COL_ID = ?",
            arrayOf(contactId.toString()),
            null,
            null,
            null
        ).use { cursor ->
            return if (cursor.moveToFirst()) {
                extractContactFromCursor(cursor)
            } else {
                null
            }
        }
    }
    
    /**
     * Deletes all emergency contacts from the database.
     * Use with caution - this operation cannot be undone.
     * 
     * @return true if any contacts were deleted, false otherwise
     */
    fun deleteAllContacts(): Boolean {
        val db = writableDatabase
        val rowsDeleted = db.delete(TABLE_CONTACTS, null, null)
        return rowsDeleted > 0
    }
}
