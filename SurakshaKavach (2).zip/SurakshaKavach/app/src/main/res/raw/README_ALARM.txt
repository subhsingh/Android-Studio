ALARM SOUND RESOURCE
====================

This folder should contain the emergency alarm sound file.

File requirements:
- Format: MP3 or OGG
- File name: emergency_alarm.mp3 or emergency_alarm.ogg
- Duration: 3-5 seconds (will loop)
- Volume: Loud and attention-grabbing
- Sample rate: 44100 Hz

You can:
1. Record your own alarm sound
2. Download a free alarm sound from freesound.org
3. Use Android's default alarm sound (fallback in code)

Note: The app will fall back to the system alarm sound if no custom alarm is found.

For now, the app uses the system default alarm sound as defined in EmergencyService.kt
