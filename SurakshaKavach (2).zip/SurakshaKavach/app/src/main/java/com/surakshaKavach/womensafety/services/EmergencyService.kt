/*
 * Copyright (c) 2026 Megha Dey. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.surakshaKavach.womensafety.services

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Vibrator
import android.telephony.SmsManager
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.surakshaKavach.womensafety.MainActivity
import com.surakshaKavach.womensafety.R
import com.surakshaKavach.womensafety.SettingsActivity
import com.surakshaKavach.womensafety.database.DatabaseHelper

/**
 * Foreground service that handles emergency response protocol execution.
 * 
 * This service orchestrates the complete emergency response workflow including:
 * - GPS location acquisition using FusedLocationProviderClient
 * - SMS alert dispatch to all configured emergency contacts
 * - Automatic emergency call initiation
 * - Audible alarm activation
 * - Device vibration patterns
 * - Persistent notification management
 * 
 * The service runs in the foreground to ensure reliable execution even
 * when the app is backgrounded or the device is under memory pressure.
 * 
 * @author Megha Dey
 * @version 1.0
 * @since 2026
 */
class EmergencyService : Service() {
    
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var vibrator: Vibrator
    private lateinit var mainHandler: Handler
    
    private var mediaPlayer: MediaPlayer? = null
    
    companion object {
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "emergency_channel"
        private const val CHANNEL_NAME = "Emergency Alerts"
        private const val ALARM_DURATION_MS = 30000L
        private const val SERVICE_STOP_DELAY_MS = 5000L
        private const val GOOGLE_MAPS_QUERY_PREFIX = "https://maps.google.com/?q="
    }
    
    /**
     * Initializes service components and creates notification channel.
     */
    override fun onCreate() {
        super.onCreate()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        dbHelper = DatabaseHelper(this)
        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        mainHandler = Handler(Looper.getMainLooper())
        
        createNotificationChannel()
    }
    
    /**
     * Starts the service in foreground mode and initiates emergency protocol.
     * 
     * @return START_NOT_STICKY to prevent automatic restart after termination
     */
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Defensive: Android 13+ can throw if notifications are disabled for the app.
        // We prefer a graceful stop over a hard crash.
        try {
            startForeground(NOTIFICATION_ID, createNotification())
        } catch (e: Exception) {
            e.printStackTrace()
            // Best-effort: still try to execute core actions quickly.
            executeEmergencyProtocol()
            stopSelf()
            return START_NOT_STICKY
        }
        executeEmergencyProtocol()
        return START_NOT_STICKY
    }
    
    /**
     * Executes the complete emergency response protocol.
     * 
     * Workflow:
     * 1. Acquire current GPS location
     * 2. Send SMS alerts with location to all contacts
     * 3. Initiate emergency call
     * 4. Activate audible alarm
     * 5. Trigger vibration pattern
     * 6. Update notification with status
     * 
     * If location is unavailable, proceeds with other steps using fallback message.
     */
    private fun executeEmergencyProtocol() {
        getCurrentLocation { location ->
            val locationInfo = if (location != null) {
                formatLocationUrl(location)
            } else {
                getString(R.string.location_unavailable)
            }
            
            dispatchEmergencyActions(locationInfo)
            updateNotification(
                if (location != null) {
                    getString(R.string.emergency_activated_success)
                } else {
                    getString(R.string.emergency_activated_no_location)
                }
            )
        }
    }
    
    /**
     * Dispatches all emergency actions in parallel.
     */
    private fun dispatchEmergencyActions(locationInfo: String) {
        sendSMSAlerts(locationInfo)
        makeEmergencyCall()
        soundAlarm()
        vibratePhone()
    }
    
    /**
     * Formats location coordinates into Google Maps URL.
     */
    private fun formatLocationUrl(location: Location): String {
        return "$GOOGLE_MAPS_QUERY_PREFIX${location.latitude},${location.longitude}"
    }
    
    /**
     * Retrieves current device location using high-accuracy GPS.
     * 
     * @param callback Function to receive location result or null if unavailable
     */
    private fun getCurrentLocation(callback: (Location?) -> Unit) {
        val priority = when {
            hasFineLocationPermission() -> Priority.PRIORITY_HIGH_ACCURACY
            hasCoarseLocationPermission() -> Priority.PRIORITY_BALANCED_POWER_ACCURACY
            else -> {
                callback(null)
                return
            }
        }

        fusedLocationClient.getCurrentLocation(priority, null)
            .addOnSuccessListener { location ->
                if (location != null) {
                    callback(location)
                } else {
                    // Fallback: last known location (may be stale but better than null).
                    fusedLocationClient.lastLocation
                        .addOnSuccessListener { last -> callback(last) }
                        .addOnFailureListener { callback(null) }
                }
            }
            .addOnFailureListener {
                // Fallback: last known location.
                fusedLocationClient.lastLocation
                    .addOnSuccessListener { last -> callback(last) }
                    .addOnFailureListener { callback(null) }
            }
    }
    
    /**
     * Checks if location permission is granted.
     */
    private fun hasLocationPermission(): Boolean {
        return hasFineLocationPermission() || hasCoarseLocationPermission()
    }

    private fun hasFineLocationPermission(): Boolean {
        return ActivityCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun hasCoarseLocationPermission(): Boolean {
        return ActivityCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }
    
    /**
     * Sends SMS alerts to all configured emergency contacts.
     * 
     * @param location Location information to include in the alert message
     */
    private fun sendSMSAlerts(location: String) {
        if (!hasSmsPermission()) return
        
        val message = buildAlertMessage(location)
        val contacts = dbHelper.getAllContacts()
        val smsManager = SmsManager.getDefault()
        
        contacts.forEach { contact ->
            sendSmsToContact(smsManager, contact.phoneNumber, message)
        }
    }
    
    /**
     * Builds the complete alert message including location.
     */
    private fun buildAlertMessage(location: String): String {
        val prefs = getSharedPreferences(SettingsActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val alertMessage = prefs.getString(
            SettingsActivity.KEY_ALERT_MESSAGE,
            SettingsActivity.DEFAULT_ALERT_MESSAGE
        ) ?: SettingsActivity.DEFAULT_ALERT_MESSAGE

        // Ensure the location starts on a new line for readability.
        val separator = if (alertMessage.endsWith(" ") || alertMessage.endsWith("\n")) "" else "\n"
        return "$alertMessage$separator$location"
    }
    
    /**
     * Sends SMS to a single contact with error handling.
     */
    private fun sendSmsToContact(smsManager: SmsManager, phoneNumber: String, message: String) {
        try {
            val parts = smsManager.divideMessage(message)
            if (parts.size > 1) {
                smsManager.sendMultipartTextMessage(phoneNumber, null, parts, null, null)
            } else {
                smsManager.sendTextMessage(phoneNumber, null, message, null, null)
            }
        } catch (e: Exception) {
            // Log error but continue with other contacts
            e.printStackTrace()
        }
    }
    
    /**
     * Checks if SMS permission is granted.
     */
    private fun hasSmsPermission(): Boolean {
        return ActivityCompat.checkSelfPermission(
            this,
            Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
    }
    
    /**
     * Initiates emergency call if auto-call is enabled in settings.
     * Requires CALL_PHONE permission.
     */
    private fun makeEmergencyCall() {
        val prefs = getSharedPreferences(SettingsActivity.PREFS_NAME, Context.MODE_PRIVATE)
        
        if (!isAutoCallEnabled(prefs) || !hasCallPermission()) {
            return
        }
        
        val emergencyNumber = getEmergencyNumber(prefs)
        initiateCall(emergencyNumber)
    }
    
    /**
     * Checks if auto-call feature is enabled.
     */
    private fun isAutoCallEnabled(prefs: android.content.SharedPreferences): Boolean {
        return prefs.getBoolean(SettingsActivity.KEY_AUTO_CALL, true)
    }
    
    /**
     * Retrieves configured emergency number from settings.
     */
    private fun getEmergencyNumber(prefs: android.content.SharedPreferences): String {
        return prefs.getString(
            SettingsActivity.KEY_EMERGENCY_NUMBER,
            SettingsActivity.DEFAULT_EMERGENCY_NUMBER
        ) ?: SettingsActivity.DEFAULT_EMERGENCY_NUMBER
    }
    
    /**
     * Initiates phone call to the specified number.
     */
    private fun initiateCall(phoneNumber: String) {
        try {
            val callIntent = Intent(Intent.ACTION_CALL).apply {
                data = Uri.parse("tel:$phoneNumber")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(callIntent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    /**
     * Checks if call permission is granted.
     */
    private fun hasCallPermission(): Boolean {
        return ActivityCompat.checkSelfPermission(
            this,
            Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED
    }
    
    /**
     * Plays a loud, looping alarm sound to attract attention.
     *
     * Uses system-provided alarm/notification sounds (no bundled audio file required),
     * which keeps the app lightweight and avoids missing-resource crashes.
     */
    private fun soundAlarm() {
        val prefs = getSharedPreferences(SettingsActivity.PREFS_NAME, Context.MODE_PRIVATE)
        val enableAlarm = prefs.getBoolean(SettingsActivity.KEY_ENABLE_ALARM, true)
        if (!enableAlarm) return

        // Ensure we start from a clean state.
        stopAlarm()

        // Candidate URIs ordered by preference.
        val candidateUris = listOfNotNull(
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE),
            Uri.parse("content://settings/system/alarm_alert"),
        )

        for (uri in candidateUris) {
            try {
                mediaPlayer = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .build()
                    )
                    setDataSource(applicationContext, uri)
                    isLooping = true
                    setVolume(1.0f, 1.0f)
                    prepare()
                    start()
                }
                break
            } catch (e: Exception) {
                // Try the next URI candidate.
                stopAlarm()
            }
        }

        if (mediaPlayer == null) return

        mainHandler.postDelayed({ stopAlarm() }, ALARM_DURATION_MS)
    }
    
    private fun vibratePhone() {
        try {
            // Vibrate pattern: 0ms delay, 1000ms vibrate, 500ms pause, repeat
            val pattern = longArrayOf(0, 1000, 500, 1000, 500, 1000)
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(
                    android.os.VibrationEffect.createWaveform(pattern, -1)
                )
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(pattern, -1)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    private fun stopAlarm() {
        mediaPlayer?.let {
            if (it.isPlaying) {
                it.stop()
            }
            it.release()
        }
        mediaPlayer = null
    }
    
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Emergency alert notifications"
                setSound(null, null)
            }
            
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }
    
    /**
     * Creates initial notification for foreground service.
     */
    private fun createNotification() =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.emergency_notification_title))
            .setContentText(getString(R.string.emergency_notification_text))
            .setSmallIcon(R.drawable.ic_emergency)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true)
            .setContentIntent(createPendingIntent())
            .build()
    
    /**
     * Updates notification with completion status.
     * 
     * @param message Status message to display
     */
    private fun updateNotification(message: String) {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.emergency_notification_title))
            .setContentText(message)
            .setSmallIcon(R.drawable.ic_emergency)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(false)
            .setAutoCancel(true)
            .setContentIntent(createPendingIntent())
            .build()
        
        getSystemService(NotificationManager::class.java)
            ?.let { manager ->
                try {
                    manager.notify(NOTIFICATION_ID, notification)
                } catch (e: Exception) {
                    // Notifications may be disabled; ignore to avoid crashing emergency flow.
                    e.printStackTrace()
                }
            }
        
        mainHandler.postDelayed({
            stopSelf()
        }, SERVICE_STOP_DELAY_MS)
    }
    
    private fun createPendingIntent(): PendingIntent {
        val intent = Intent(this, MainActivity::class.java)
        return PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE
        )
    }
    
    /**
     * Cleans up resources when service is destroyed.
     */
    override fun onDestroy() {
        super.onDestroy()
        stopAlarm()
        vibrator.cancel()
        mainHandler.removeCallbacksAndMessages(null)
    }
    
    /**
     * Returns null as this service does not support binding.
     */
    override fun onBind(intent: Intent?): IBinder? = null
}
