package com.surakshaKavach.womensafety

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.surakshaKavach.womensafety.adapters.ContactsAdapter
import com.surakshaKavach.womensafety.database.DatabaseHelper
import com.surakshaKavach.womensafety.databinding.ActivityEmergencyContactsBinding
import com.surakshaKavach.womensafety.databinding.DialogAddContactBinding
import com.surakshaKavach.womensafety.models.EmergencyContact

/**
 * EmergencyContactsActivity - Manage emergency contacts
 * Users can add, edit, and delete emergency contacts
 */
class EmergencyContactsActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityEmergencyContactsBinding
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var adapter: ContactsAdapter
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEmergencyContactsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Emergency Contacts"
        
        dbHelper = DatabaseHelper(this)
        
        setupRecyclerView()
        setupFAB()
        loadContacts()
    }
    
    private fun setupRecyclerView() {
        adapter = ContactsAdapter(
            onDeleteClick = { contact ->
                showDeleteConfirmation(contact)
            },
            onEditClick = { contact ->
                showAddContactDialog(contact)
            }
        )
        
        binding.recyclerViewContacts.apply {
            layoutManager = LinearLayoutManager(this@EmergencyContactsActivity)
            adapter = this@EmergencyContactsActivity.adapter
        }
    }
    
    private fun setupFAB() {
        binding.fabAddContact.setOnClickListener {
            showAddContactDialog()
        }
    }
    
    private fun loadContacts() {
        val contacts = dbHelper.getAllContacts()
        adapter.submitList(contacts)
        
        if (contacts.isEmpty()) {
            binding.tvEmptyState.visibility = android.view.View.VISIBLE
            binding.recyclerViewContacts.visibility = android.view.View.GONE
        } else {
            binding.tvEmptyState.visibility = android.view.View.GONE
            binding.recyclerViewContacts.visibility = android.view.View.VISIBLE
        }
    }
    
    private fun showAddContactDialog(contact: EmergencyContact? = null) {
        val dialogBinding = DialogAddContactBinding.inflate(LayoutInflater.from(this))
        
        // Pre-fill if editing
        contact?.let {
            dialogBinding.etContactName.setText(it.name)
            dialogBinding.etContactPhone.setText(it.phoneNumber)
            dialogBinding.etContactRelation.setText(it.relationship)
        }
        
        MaterialAlertDialogBuilder(this)
            .setTitle(if (contact == null) "Add Contact" else "Edit Contact")
            .setView(dialogBinding.root)
            .setPositiveButton(if (contact == null) "Add" else "Update") { _, _ ->
                val name = dialogBinding.etContactName.text.toString().trim()
                val phone = dialogBinding.etContactPhone.text.toString().trim()
                val relation = dialogBinding.etContactRelation.text.toString().trim()
                
                if (validateInput(name, phone)) {
                    if (contact == null) {
                        // Add new contact
                        val newContact = EmergencyContact(
                            name = name,
                            phoneNumber = phone,
                            relationship = relation
                        )
                        val id = dbHelper.addContact(newContact)
                        if (id > 0) {
                            Toast.makeText(this, "Contact added successfully", Toast.LENGTH_SHORT).show()
                            loadContacts()
                        }
                    } else {
                        // Update existing contact
                        val updatedContact = contact.copy(
                            name = name,
                            phoneNumber = phone,
                            relationship = relation
                        )
                        val success = dbHelper.updateContact(updatedContact)
                        if (success) {
                            Toast.makeText(this, "Contact updated successfully", Toast.LENGTH_SHORT).show()
                            loadContacts()
                        }
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun validateInput(name: String, phone: String): Boolean {
        if (name.isEmpty()) {
            Toast.makeText(this, "Please enter contact name", Toast.LENGTH_SHORT).show()
            return false
        }
        
        if (phone.isEmpty()) {
            Toast.makeText(this, "Please enter phone number", Toast.LENGTH_SHORT).show()
            return false
        }
        
        if (phone.length < 10) {
            Toast.makeText(this, "Please enter a valid phone number", Toast.LENGTH_SHORT).show()
            return false
        }
        
        return true
    }
    
    private fun showDeleteConfirmation(contact: EmergencyContact) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Delete Contact")
            .setMessage("Are you sure you want to delete ${contact.name}?")
            .setPositiveButton("Delete") { _, _ ->
                val success = dbHelper.deleteContact(contact.id)
                if (success) {
                    Toast.makeText(this, "Contact deleted", Toast.LENGTH_SHORT).show()
                    loadContacts()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
