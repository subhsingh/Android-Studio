/*
 * Copyright (c) 2026 Megha Dey. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 */

package com.surakshaKavach.womensafety.utils

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

/**
 * Singleton utility object for managing runtime permissions.
 * 
 * This object provides a centralized interface for checking and managing
 * dangerous permissions required by the application. It handles version-specific
 * permission requirements (e.g., POST_NOTIFICATIONS for Android 13+).
 * 
 * Required Permissions:
 * - ACCESS_FINE_LOCATION: For precise GPS coordinates
 * - ACCESS_COARSE_LOCATION: For approximate location
 * - SEND_SMS: For sending emergency alerts
 * - CALL_PHONE: For emergency calling
 * - POST_NOTIFICATIONS: For notifications (Android 13+)
 * 
 * @author Megha Dey
 * @version 1.0
 * @since 2026
 */
object PermissionHelper {
    
    private val REQUIRED_PERMISSIONS = mutableListOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.SEND_SMS,
        Manifest.permission.CALL_PHONE,
    ).apply {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }.toTypedArray()
    
    /**
     * Verifies whether all required runtime permissions have been granted.
     * 
     * @param context Application or activity context
     * @return true if all permissions are granted, false otherwise
     */
    fun hasAllPermissions(context: Context): Boolean {
        return REQUIRED_PERMISSIONS.all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }
    }
    
    /**
     * Returns a list of permissions that have not yet been granted by the user.
     * 
     * @param context Application or activity context
     * @return List of permission strings that are not granted
     */
    fun getMissingPermissions(context: Context): List<String> {
        return REQUIRED_PERMISSIONS.filter {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }
    }
    
    /**
     * Checks if fine location permission (GPS) has been granted.
     * 
     * @param context Application or activity context
     * @return true if location permission is granted, false otherwise
     */
    fun hasLocationPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }
    
    /**
     * Checks if SMS sending permission has been granted.
     * 
     * @param context Application or activity context
     * @return true if SMS permission is granted, false otherwise
     */
    fun hasSmsPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
    }
    
    /**
     * Checks if phone call permission has been granted.
     * 
     * @param context Application or activity context
     * @return true if call permission is granted, false otherwise
     */
    fun hasCallPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED
    }
}
