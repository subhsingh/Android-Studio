/*
 * Copyright (c) 2026 Megha Dey. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 */

package com.surakshaKavach.womensafety.models

/**
 * Data class representing an emergency contact entity.
 * 
 * This immutable data class encapsulates all information about an emergency contact
 * that can be notified during emergency situations.
 * 
 * @property id Unique identifier for the contact (database primary key)
 * @property name Full name of the emergency contact
 * @property phoneNumber Contact's phone number in international or local format
 * @property relationship Optional relationship description (e.g., "Mother", "Friend")
 * 
 * @author Megha Dey
 * @version 1.0
 * @since 2026
 */
data class EmergencyContact(
    val id: Long = 0,
    val name: String,
    val phoneNumber: String,
    val relationship: String = ""
)
