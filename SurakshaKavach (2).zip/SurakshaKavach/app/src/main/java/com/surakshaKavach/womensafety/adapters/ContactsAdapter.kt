package com.surakshaKavach.womensafety.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.surakshaKavach.womensafety.databinding.ItemContactBinding
import com.surakshaKavach.womensafety.models.EmergencyContact

/**
 * ContactsAdapter - RecyclerView adapter for displaying emergency contacts
 */
class ContactsAdapter(
    private val onDeleteClick: (EmergencyContact) -> Unit,
    private val onEditClick: (EmergencyContact) -> Unit
) : ListAdapter<EmergencyContact, ContactsAdapter.ContactViewHolder>(ContactDiffCallback()) {
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactViewHolder {
        val binding = ItemContactBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ContactViewHolder(binding)
    }
    
    override fun onBindViewHolder(holder: ContactViewHolder, position: Int) {
        holder.bind(getItem(position))
    }
    
    inner class ContactViewHolder(
        private val binding: ItemContactBinding
    ) : RecyclerView.ViewHolder(binding.root) {
        
        fun bind(contact: EmergencyContact) {
            binding.apply {
                tvContactName.text = contact.name
                tvContactPhone.text = contact.phoneNumber
                tvContactRelation.text = contact.relationship.ifEmpty { "No relationship specified" }
                
                btnDelete.setOnClickListener {
                    onDeleteClick(contact)
                }
                
                root.setOnClickListener {
                    onEditClick(contact)
                }
            }
        }
    }
    
    private class ContactDiffCallback : DiffUtil.ItemCallback<EmergencyContact>() {
        override fun areItemsTheSame(oldItem: EmergencyContact, newItem: EmergencyContact): Boolean {
            return oldItem.id == newItem.id
        }
        
        override fun areContentsTheSame(oldItem: EmergencyContact, newItem: EmergencyContact): Boolean {
            return oldItem == newItem
        }
    }
}
