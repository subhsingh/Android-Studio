/*
 * Copyright (c) 2026 Megha Dey. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.surakshaKavach.womensafety

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.surakshaKavach.womensafety.databinding.ActivityEvidencePhotoBinding
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Optional evidence photo capture screen.
 *
 * This activity uses CameraX to capture a single photo on-demand. Photos are stored in
 * app-private storage and can be shared securely using a FileProvider.
 *
 * Camera permission is requested at runtime only when this feature is used.
 *
 * @author Megha Dey
 * @version 1.0
 * @since 2026
 */
class EvidencePhotoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEvidencePhotoBinding

    private var imageCapture: ImageCapture? = null

    companion object {
        private const val CAMERA_PERMISSION_REQUEST_CODE = 2001
        private const val EVIDENCE_DIR_NAME = "evidence"
        private const val EVIDENCE_FILE_PREFIX = "evidence_"
        private const val EVIDENCE_FILE_EXTENSION = ".jpg"
        private const val EVIDENCE_TIMESTAMP_PATTERN = "yyyyMMdd_HHmmss"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEvidencePhotoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.evidence_photo_title)

        binding.btnCapturePhoto.setOnClickListener {
            takePhoto()
        }
    }

    override fun onStart() {
        super.onStart()

        if (!isEvidencePhotoEnabled()) {
            Toast.makeText(this, getString(R.string.evidence_photo_disabled_message), Toast.LENGTH_LONG).show()
            finish()
            return
        }

        if (!hasCameraHardware()) {
            showCameraUnavailableDialog()
            return
        }

        ensureCameraPermissionAndStart()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    private fun isEvidencePhotoEnabled(): Boolean {
        val prefs = getSharedPreferences(SettingsActivity.PREFS_NAME, MODE_PRIVATE)
        return prefs.getBoolean(SettingsActivity.KEY_ENABLE_EVIDENCE_PHOTO, false)
    }

    private fun hasCameraHardware(): Boolean {
        return packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)
    }

    private fun showCameraUnavailableDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.camera_unavailable_title))
            .setMessage(getString(R.string.camera_unavailable_message))
            .setPositiveButton(getString(R.string.ok)) { _, _ -> finish() }
            .setCancelable(false)
            .show()
    }

    private fun ensureCameraPermissionAndStart() {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED

        if (granted) {
            startCamera()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.CAMERA),
                CAMERA_PERMISSION_REQUEST_CODE
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            if (granted) {
                startCamera()
            } else {
                showCameraPermissionRequiredDialog()
            }
        }
    }

    private fun showCameraPermissionRequiredDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.camera_permission_required_title))
            .setMessage(getString(R.string.camera_permission_required_message))
            .setPositiveButton(getString(R.string.ok)) { _, _ -> finish() }
            .setCancelable(false)
            .show()
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener(
            {
                val cameraProvider = cameraProviderFuture.get()

                val preview = Preview.Builder()
                    .build()
                    .also { it.setSurfaceProvider(binding.previewView.surfaceProvider) }

                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()

                val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

                try {
                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageCapture)
                } catch (e: Exception) {
                    Toast.makeText(this, getString(R.string.camera_start_failed), Toast.LENGTH_LONG).show()
                    finish()
                }
            },
            ContextCompat.getMainExecutor(this)
        )
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return

        binding.btnCapturePhoto.isEnabled = false

        val evidenceDir = File(filesDir, EVIDENCE_DIR_NAME).apply { mkdirs() }
        val timestamp = SimpleDateFormat(EVIDENCE_TIMESTAMP_PATTERN, Locale.US).format(Date())
        val outputFile = File(evidenceDir, "$EVIDENCE_FILE_PREFIX$timestamp$EVIDENCE_FILE_EXTENSION")

        val outputOptions = ImageCapture.OutputFileOptions.Builder(outputFile).build()

        capture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    binding.btnCapturePhoto.isEnabled = true
                    showPhotoSavedDialog(outputFile)
                }

                override fun onError(exception: ImageCaptureException) {
                    binding.btnCapturePhoto.isEnabled = true
                    Toast.makeText(
                        this@EvidencePhotoActivity,
                        getString(R.string.photo_capture_failed),
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        )
    }

    private fun showPhotoSavedDialog(file: File) {
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.photo_saved_title))
            .setMessage(getString(R.string.photo_saved_message))
            .setPositiveButton(getString(R.string.share)) { _, _ ->
                sharePhoto(file)
            }
            .setNegativeButton(getString(R.string.close), null)
            .show()
    }

    private fun sharePhoto(file: File) {
        val uri = FileProvider.getUriForFile(
            this,
            "${BuildConfig.APPLICATION_ID}.fileprovider",
            file
        )

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        startActivity(Intent.createChooser(shareIntent, getString(R.string.share_photo)))
    }

    override fun onDestroy() {
        super.onDestroy()
    }
}
