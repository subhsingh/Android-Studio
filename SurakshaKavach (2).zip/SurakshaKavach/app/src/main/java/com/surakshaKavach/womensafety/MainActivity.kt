/*
 * Copyright (c) 2026 Megha Dey. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.surakshaKavach.womensafety

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.surakshaKavach.womensafety.databinding.ActivityMainBinding
import com.surakshaKavach.womensafety.services.EmergencyService
import com.surakshaKavach.womensafety.utils.PermissionHelper
import com.surakshaKavach.womensafety.database.DatabaseHelper

/**
 * Main activity serving as the entry point for the Suraksha Kavach application.
 * 
 * This activity manages the primary user interface including:
 * - Emergency panic button with long-press activation mechanism
 * - Permission management and status display
 * - Navigation to emergency contacts and settings
 * - Application information display
 * 
 * @author Megha Dey
 * @version 1.0
 * @since 2026
 */
class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    private lateinit var dbHelper: DatabaseHelper
    
    companion object {
        private const val PERMISSION_REQUEST_CODE = 1001
        private const val PANIC_HOLD_DURATION_MS = 2000L
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        dbHelper = DatabaseHelper(this)
        
        setupUI()
        checkPermissions()
    }
    
    /**
     * Initializes the user interface components and sets up event listeners.
     * Configures the panic button, navigation buttons, and updates contact status.
     */
    private fun setupUI() {
        binding.panicButton.setOnLongClickListener {
            activateEmergency()
            true
        }
        
        binding.panicButton.setOnClickListener {
            Toast.makeText(
                this,
                getString(R.string.panic_instruction),
                Toast.LENGTH_SHORT
            ).show()
        }
        
        binding.btnEmergencyContacts.setOnClickListener {
            startActivity(Intent(this, EmergencyContactsActivity::class.java))
        }
        
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        binding.btnEvidencePhoto.setOnClickListener {
            openEvidencePhoto()
        }
        
        binding.btnAbout.setOnClickListener {
            showAboutDialog()
        }
        
        updateContactsCount()
        updateEvidencePhotoButtonVisibility()
    }
    
    /**
     * Validates emergency prerequisites and displays confirmation dialog.
     * Ensures at least one emergency contact exists before proceeding.
     */
    private fun activateEmergency() {
        val contacts = dbHelper.getAllContacts()
        if (contacts.isEmpty()) {
            showNoContactsDialog()
            return
        }
        
        showEmergencyConfirmationDialog()
    }
    
    /**
     * Displays dialog when no emergency contacts are configured.
     */
    private fun showNoContactsDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.no_contacts_title))
            .setMessage(getString(R.string.no_contacts_message))
            .setPositiveButton(getString(R.string.add_contacts)) { _, _ ->
                startActivity(Intent(this, EmergencyContactsActivity::class.java))
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }
    
    /**
     * Displays final confirmation dialog before activating emergency protocol.
     */
    private fun showEmergencyConfirmationDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.emergency_confirm_title))
            .setMessage(getString(R.string.emergency_confirm_message))
            .setPositiveButton(getString(R.string.activate)) { _, _ ->
                triggerEmergency()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .setCancelable(true)
            .show()
    }
    
    /**
     * Initiates the emergency response protocol by starting the EmergencyService.
     * Verifies all required permissions are granted before proceeding.
     */
    private fun triggerEmergency() {
        if (!PermissionHelper.hasAllPermissions(this)) {
            Toast.makeText(
                this,
                getString(R.string.permissions_required_first),
                Toast.LENGTH_LONG
            ).show()
            checkPermissions()
            return
        }

        // Android 13+ can throw when starting a foreground service if notifications are disabled.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !NotificationManagerCompat.from(this).areNotificationsEnabled()
        ) {
            showNotificationsDisabledDialog()
            return
        }
        
        val intent = Intent(this, EmergencyService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        
        Toast.makeText(
            this,
            getString(R.string.emergency_activated),
            Toast.LENGTH_LONG
        ).show()
    }

    private fun showNotificationsDisabledDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.notifications_disabled_title))
            .setMessage(getString(R.string.notifications_disabled_message))
            .setPositiveButton(getString(R.string.open_system_settings)) { _, _ ->
                openAppNotificationSettings()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun openAppNotificationSettings() {
        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
            putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
        }
        startActivity(intent)
    }
    
    /**
     * Verifies runtime permissions and prompts user if any are missing.
     * Updates UI to reflect current permission status.
     */
    private fun checkPermissions() {
        val missingPermissions = PermissionHelper.getMissingPermissions(this)
        
        if (missingPermissions.isNotEmpty()) {
            showPermissionRationaleDialog(missingPermissions)
        } else {
            updatePermissionStatusGranted()
        }
    }
    
    /**
     * Displays rationale dialog explaining why permissions are required.
     */
    private fun showPermissionRationaleDialog(permissions: List<String>) {
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.permission_required))
            .setMessage(getString(R.string.permission_explanation))
            .setPositiveButton(getString(R.string.grant_permissions)) { _, _ ->
                ActivityCompat.requestPermissions(
                    this,
                    permissions.toTypedArray(),
                    PERMISSION_REQUEST_CODE
                )
            }
            .setCancelable(false)
            .show()
    }
    
    /**
     * Updates UI to indicate all permissions have been granted.
     */
    private fun updatePermissionStatusGranted() {
        binding.tvPermissionStatus.text = getString(R.string.all_permissions_granted)
        binding.tvPermissionStatus.setTextColor(
            ContextCompat.getColor(this, R.color.green)
        )
    }
    
    /**
     * Handles the result of runtime permission requests.
     * Updates UI based on whether permissions were granted or denied.
     */
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        
        if (requestCode == PERMISSION_REQUEST_CODE) {
            handlePermissionResult(grantResults)
        }
    }
    
    /**
     * Processes permission grant results and updates UI accordingly.
     */
    private fun handlePermissionResult(grantResults: IntArray) {
        val allGranted = grantResults.all { it == PackageManager.PERMISSION_GRANTED }
        
        if (allGranted) {
            updatePermissionStatusGranted()
            Toast.makeText(
                this,
                getString(R.string.permissions_granted_success),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            updatePermissionStatusDenied()
            Toast.makeText(
                this,
                getString(R.string.permissions_denied_warning),
                Toast.LENGTH_LONG
            ).show()
        }
    }
    
    /**
     * Updates UI to indicate some permissions were denied.
     */
    private fun updatePermissionStatusDenied() {
        binding.tvPermissionStatus.text = getString(R.string.permissions_missing)
        binding.tvPermissionStatus.setTextColor(
            ContextCompat.getColor(this, R.color.orange)
        )
    }
    
    /**
     * Updates the contact count display based on stored emergency contacts.
     */
    private fun updateContactsCount() {
        val count = dbHelper.getAllContacts().size
        binding.tvContactsCount.text = resources.getQuantityString(
            R.plurals.contacts_count,
            count,
            count
        )
    }
    
    /**
     * Called when the activity is resumed. Refreshes contact count display.
     */
    override fun onResume() {
        super.onResume()
        updateContactsCount()
        updateEvidencePhotoButtonVisibility()
    }

    /**
     * Updates visibility of optional evidence photo feature based on settings.
     */
    private fun updateEvidencePhotoButtonVisibility() {
        binding.btnEvidencePhoto.visibility =
            if (isEvidencePhotoEnabled()) View.VISIBLE else View.GONE
    }

    private fun isEvidencePhotoEnabled(): Boolean {
        val prefs = getSharedPreferences(SettingsActivity.PREFS_NAME, MODE_PRIVATE)
        return prefs.getBoolean(SettingsActivity.KEY_ENABLE_EVIDENCE_PHOTO, false)
    }

    private fun openEvidencePhoto() {
        // Defensive check in case the UI is invoked while disabled.
        if (!isEvidencePhotoEnabled()) {
            MaterialAlertDialogBuilder(this)
                .setTitle(getString(R.string.evidence_photo_settings_title))
                .setMessage(getString(R.string.evidence_photo_disabled_message))
                .setPositiveButton(getString(R.string.settings)) { _, _ ->
                    startActivity(Intent(this, SettingsActivity::class.java))
                }
                .setNegativeButton(getString(R.string.cancel), null)
                .show()
            return
        }

        startActivity(Intent(this, EvidencePhotoActivity::class.java))
    }
    
    /**
     * Displays application information dialog with features and version details.
     */
    private fun showAboutDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.about_title))
            .setMessage(getString(R.string.about_message))
            .setPositiveButton(getString(R.string.ok), null)
            .show()
    }
}
